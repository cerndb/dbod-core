dbod_core_base=/opt/dbod/perl5
export PERL5LIB=${PERL5LIB}:${dbod_core_base}
export PATH=${PATH}:${dbod_core_base}/bin

